
export interface Team {
    id?: string;
    name: string;
    country: string;
}
