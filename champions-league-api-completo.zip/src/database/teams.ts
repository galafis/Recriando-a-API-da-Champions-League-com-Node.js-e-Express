
import { Team } from '../models/team';

export const teams: Team[] = [];
